export const Config = { apiUrl: "https://dmgctrlback.aristech.gr/api/v1/" };
//export const Config = { apiUrl: "http://localhost:8000/api/v1/" };
//export const Config = { apiUrl: "https://atlback.aristech.gr/api/v1/" };
